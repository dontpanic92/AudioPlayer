//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MediaPlayer.rc
//
#define IDD_FORMVIEW                    101
#define IDC_CURRENTMUSIC                1005
#define IDC_BUTTONBROWSE                1006
#define IDC_INFO                        1007
#define IDC_POSITIONCTRL                1009
#define IDC_TIME                        1010
#define IDC_SLIDER4                     1011
#define IDC_VOLUMECTRL                  1011
#define IDC_VOLUME                      1012
#define IDC_BUTTON4                     1013
#define IDC_BUTTONPLAY                  1013
#define IDC_BUTTON5                     1014
#define IDC_BUTTONSTOP                  1014
#define IDC_BUTTON1                     1018
#define IDC_CHANGEUI                    1018
#define IDC_LISTMUSIC                   1019
#define IDC_BUTTONADD                   1020
#define IDC_BUTTON3                     1021
#define IDC_BUTTONDEL                   1021
#define IDC_COMBO3                      1024
#define IDC_COMBO1                      1026
#define IDC_COMBOMODE                   1026
#define IDC_BUTTONCA                    1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
